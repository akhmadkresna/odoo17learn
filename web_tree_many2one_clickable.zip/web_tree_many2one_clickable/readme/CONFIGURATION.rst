After installation, all many2one and reference fields will be clickable by default.
