This addon forces Odoo to use many2one widget on a many2one fields in
tree views. This allows users to open linked resources from trees directly,
using a button without accessing the form.
