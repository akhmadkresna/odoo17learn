* Therp BV
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Antonio Espinosa <antonio.espinosa@tecnativa.com>
* Sodexis <dev@sodexis.com>
* Artem Kostyuk <a.kostyuk@mobilunity.com>
* Anand Kansagra <kansagraanand@hotmail.com>
* Alexandre Díaz <alexandre.diaz@tecnativa.com>
* Dennis Sluijk <d.sluijk@onestein.nl>
