This widget is currently not working on the product field in the lines tree of the
sale order form, see https://github.com/OCA/web/pull/1438 for further details.

To add this functionality to lines of sales, purchases and invoices, as they are
special views, is required a glue module that add this feature.
